<?php $__env->startSection('title', $user->name . ' - User Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="m-3 sm:m-5">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb bg-light p-2 rounded shadow-sm">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('users.index')); ?>" class="text-decoration-none">
                    <i class="fas fa-users me-1"></i> Users
                </a>
            </li>
            <li class="breadcrumb-item active"><?php echo e($user->name); ?></li>
        </ol>
    </nav>

    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="mb-0">
            <i class="fas fa-user-circle text-primary me-2"></i> <?php echo e($user->name); ?>

        </h3>
        <?php if($user->id !== Auth::id()): ?>
            <div class="btn-group">
                <a href="<?php echo e(route('users.edit', $user)); ?>" class="btn btn-sm btn-outline-primary">
                    <i class="fas fa-edit me-1"></i> Edit
                </a>
                <form action="<?php echo e(route('users.destroy', $user)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-sm btn-outline-danger"
                        onclick="return confirm('Delete <?php echo e($user->name); ?> permanently?')">
                        <i class="fas fa-trash me-1"></i> Delete
                    </button>
                </form>
            </div>
        <?php endif; ?>
    </div>

    <div class="row">
        <!-- Left Column -->
        <div class="col-lg-8 mb-4">
            <!-- User Info Card -->
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-white fw-bold">
                    <i class="fas fa-id-card me-2"></i> User Information
                </div>
                <div class="card-body">
                    <p><strong>Email:</strong> <?php echo e($user->email); ?></p>
                    <p><strong>Role:</strong>
                        <span class="badge bg-<?php echo e($user->role === 'admin' ? 'danger' : ($user->role === 'teacher' ? 'warning text-dark' : 'info')); ?>">
                            <?php echo e(ucfirst($user->role)); ?>

                        </span>
                    </p>
                    <p><strong>Joined:</strong> <?php echo e($user->created_at->format('M d, Y')); ?></p>
                </div>
            </div>

            <!-- Courses Created -->
            <?php if($user->courses->count() > 0): ?>
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-white fw-bold">
                    <i class="fas fa-book me-2"></i> Courses Created
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php $__currentLoopData = $user->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 mb-3">
                            <div class="card h-100 border-0 shadow-sm">
                                <div class="card-body">
                                    <h6 class="fw-bold">
                                        <i class="fas fa-graduation-cap text-primary me-1"></i> <?php echo e($course->name); ?>

                                    </h6>
                                    <p class="text-muted small"><?php echo e(Str::limit($course->description, 80)); ?></p>
                                    <span class="badge bg-success"><?php echo e($course->enrollments->count()); ?> students</span>
                                    <a href="<?php echo e(route('courses.show', $course)); ?>" class="btn btn-sm btn-outline-primary mt-2">View</a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Enrolled Courses -->
            <?php if($user->enrolledCourses->count() > 0): ?>
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-white fw-bold">
                    <i class="fas fa-chalkboard-teacher me-2"></i> Enrolled Courses
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php $__currentLoopData = $user->enrolledCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 mb-3">
                            <div class="card h-100 border-0 shadow-sm">
                                <div class="card-body">
                                    <h6 class="fw-bold">
                                        <i class="fas fa-graduation-cap text-primary me-1"></i> <?php echo e($course->name); ?>

                                    </h6>
                                    <p class="text-muted small"><?php echo e(Str::limit($course->description, 80)); ?></p>
                                    <span class="badge bg-secondary">By <?php echo e($course->user->name); ?></span>
                                    <a href="<?php echo e(route('courses.show', $course)); ?>" class="btn btn-sm btn-outline-primary mt-2">View</a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Right Column -->
        <div class="col-lg-4">
            <div class="card shadow-sm">
                <div class="card-body text-center">
                    <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center mx-auto mb-3" style="width:80px;height:80px;font-size:2rem;">
                        <?php echo e(strtoupper(substr($user->name, 0, 1))); ?>

                    </div>
                    <h5><?php echo e($user->name); ?></h5>
                    <p class="text-muted"><?php echo e($user->email); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\lms\resources\views/users/show.blade.php ENDPATH**/ ?>