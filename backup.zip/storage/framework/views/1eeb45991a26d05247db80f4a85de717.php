<?php $__env->startSection('title', 'Edit Post - ' . $post->title); ?>

<?php $__env->startSection('content'); ?>
<script src="https://cdn.tailwindcss.com"></script>
<div class="m-3 sm:m-5">

    <!-- Breadcrumb -->
    <nav class="flex text-sm text-gray-600 mb-6" aria-label="Breadcrumb">
        <ol class="inline-flex items-center space-x-2">
            <li>
                <a href="<?php echo e(route('courses.index')); ?>" class="hover:text-blue-600 flex items-center">
                    <i class="fas fa-home mr-1"></i> Courses
                </a>
            </li>
            <li>
                <span class="mx-1">/</span>
                <a href="<?php echo e(route('courses.show', $post->course)); ?>" class="hover:text-blue-600">
                    <?php echo e($post->course->name); ?>

                </a>
            </li>
            <li>
                <span class="mx-1">/</span>
                <a href="<?php echo e(route('posts.show', $post)); ?>" class="hover:text-blue-600">
                    <?php echo e($post->title); ?>

                </a>
            </li>
            <li>
                <span class="mx-1">/</span>
                <span class="text-gray-400">Edit</span>
            </li>
        </ol>
    </nav>

    <!-- Page Header -->
    <div class="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
        <div>
            <h1 class="text-2xl font-bold text-gray-800 flex items-center gap-2">
                <i class="fas fa-edit text-blue-500"></i>
                Edit Post
            </h1>
            <p class="text-gray-500 mt-1">Update post: <?php echo e($post->title); ?></p>
        </div>
        <a href="<?php echo e(route('posts.show', $post)); ?>" 
           class="mt-4 md:mt-0 inline-flex items-center px-4 py-2 border rounded-lg text-gray-700 border-gray-300 hover:bg-gray-100 transition">
            <i class="fas fa-arrow-left mr-2"></i> Back to Post
        </a>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Form -->
        <div class="lg:col-span-2">
            <div class="bg-white shadow rounded-2xl p-6">
                <h2 class="text-lg font-semibold text-gray-700 mb-4 flex items-center gap-2">
                    <i class="fas fa-file-alt text-blue-500"></i> Edit Post Details
                </h2>

                <form action="<?php echo e(route('posts.update', $post)); ?>" method="POST" enctype="multipart/form-data" class="space-y-5">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <!-- Title -->
                    <div>
                        <label for="title" class="block text-sm font-medium text-gray-700 mb-1">
                            <i class="fas fa-heading mr-1"></i> Post Title
                        </label>
                        <input type="text" id="title" name="title"
                               class="p-2 w-full rounded-lg border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               value="<?php echo e(old('title', $post->title)); ?>" required>
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-sm text-red-600 mt-1 flex items-center gap-1">
                                <i class="fas fa-exclamation-circle"></i> <?php echo e($message); ?>

                            </p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Content -->
                    <div>
                        <label for="content" class="block text-sm font-medium text-gray-700 mb-1">
                            <i class="fas fa-align-left mr-1"></i> Content
                        </label>
                        <textarea id="content" name="content" rows="6"
                                  class="p-2 w-full rounded-lg border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                  placeholder="Write something..."><?php echo e(old('content', $post->content)); ?></textarea>
                        <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-sm text-red-600 mt-1 flex items-center gap-1">
                                <i class="fas fa-exclamation-circle"></i> <?php echo e($message); ?>

                            </p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- File -->
                    <div>
                        <label for="file" class="block text-sm font-medium text-gray-700 mb-1">
                            <i class="fas fa-file-upload mr-1"></i> File (optional)
                        </label>
                        <input type="file" id="file" name="file"
                               class="w-full text-gray-700 file:mr-4 file:py-2 file:px-4 
                                      file:rounded-lg file:border-0 
                                      file:text-sm file:font-semibold
                                      file:bg-blue-50 file:text-blue-600
                                      hover:file:bg-blue-100 
                                      <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-sm text-red-600 mt-1 flex items-center gap-1">
                                <i class="fas fa-exclamation-circle"></i> <?php echo e($message); ?>

                            </p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <p class="text-sm text-gray-500 mt-1">
                            <i class="fas fa-info-circle mr-1"></i> Leave empty to keep the current file.
                        </p>
                    </div>

                    <!-- Link -->
                    <div>
                        <label for="link" class="block text-sm font-medium text-gray-700 mb-1">
                            <i class="fas fa-link mr-1"></i> YouTube/Drive Link
                        </label>
                        <input type="url" id="link" name="link"
                               class="p-2 w-full rounded-lg border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500"
                               value="<?php echo e(old('link', $post->link ?? '')); ?>" placeholder="https://...">
                    </div>

                    <!-- Actions -->
                    <div class="flex justify-between items-center pt-4">
                        <a href="<?php echo e(route('posts.show', $post)); ?>" 
                           class="inline-flex items-center px-4 py-2 border rounded-lg text-gray-700 border-gray-300 hover:bg-gray-100 transition">
                            <i class="fas fa-times mr-2"></i> Cancel
                        </a>
                        <button type="submit"
                                class="inline-flex items-center px-5 py-2 bg-blue-600 text-white font-medium rounded-lg shadow hover:bg-blue-700 transition">
                            <i class="fas fa-save mr-2"></i> Update Post
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="space-y-6">
            <!-- Post Info -->
            <div class="bg-white shadow rounded-2xl p-5">
                <h3 class="text-md font-semibold text-gray-700 mb-3 flex items-center gap-2">
                    <i class="fas fa-info-circle text-blue-500"></i> Current Post Info
                </h3>
                <p><strong>Title:</strong> <span class="text-gray-600"><?php echo e($post->title); ?></span></p>
                <p class="mt-2"><strong>Type:</strong> 
                    <span class="px-2 py-1 text-xs rounded-lg 
                        <?php echo e($post->type === 'text' ? 'bg-blue-100 text-blue-600' : 
                           ($post->type === 'image' ? 'bg-green-100 text-green-600' :
                           ($post->type === 'video' ? 'bg-yellow-100 text-yellow-600' : 'bg-gray-100 text-gray-600'))); ?>">
                        <?php echo e(ucfirst($post->type)); ?>

                    </span>
                </p>
                <p class="mt-2"><strong>Course:</strong> <span class="text-gray-600"><?php echo e($post->course->name); ?></span></p>
                <p class="mt-2"><strong>Created:</strong> <span class="text-gray-600"><?php echo e($post->created_at->format('M d, Y H:i')); ?></span></p>
                <?php if($post->file_path): ?>
                    <p class="mt-2"><strong>Current File:</strong> <span class="text-gray-600"><?php echo e(basename($post->file_path)); ?></span></p>
                <?php endif; ?>
            </div>

            <!-- Preview -->
            <?php if($post->file_path): ?>
                <div class="bg-white shadow rounded-2xl p-5">
                    <h3 class="text-md font-semibold text-gray-700 mb-3 flex items-center gap-2">
                        <i class="fas fa-file text-blue-500"></i> Current File Preview
                    </h3>
                    <?php if($post->type === 'image'): ?>
                        <img src="<?php echo e(Storage::url($post->file_path)); ?>" alt="<?php echo e($post->title); ?>" class="rounded-lg w-full">
                    <?php elseif($post->type === 'video'): ?>
                        <video controls class="rounded-lg w-full max-h-64">
                            <source src="<?php echo e(Storage::url($post->file_path)); ?>" type="video/mp4">
                            Your browser does not support video.
                        </video>
                    <?php else: ?>
                        <p class="text-gray-500 text-sm">File available: <a href="<?php echo e(Storage::url($post->file_path)); ?>" target="_blank" class="text-blue-600 hover:underline"><?php echo e(basename($post->file_path)); ?></a></p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/creativy/lms.sekolahadvertiser.com/resources/views/posts/edit.blade.php ENDPATH**/ ?>