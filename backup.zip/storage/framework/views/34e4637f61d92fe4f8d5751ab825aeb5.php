<?php if($users->count()): ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Courses</th>
                <th>Enrollments</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($users->firstItem() + $index); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->courses->count()); ?></td>
                <td><?php echo e($user->enrollments->count()); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div>
        <?php echo $users->links(); ?>

    </div>
<?php else: ?>
    <p class="text-center">No users found.</p>
<?php endif; ?>
<?php /**PATH D:\lms\resources\views/users/partials/table.blade.php ENDPATH**/ ?>