

<?php $__env->startSection('title', $user->name . ' - User Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="m-3 sm:m-5">
    <div class="row">
        <!-- Left Column -->
        <div class="col-lg-8 mb-4">
            <!-- User Info Card -->
            <div class="card border-0 shadow-lg mb-4">
                <div class="card-header text-white fw-bold" style="background:#2b2738;">
                    <i class="fas fa-id-card me-2"></i> User Information
                </div>
                <div class="card-body">
                    <p><strong>Email:</strong> <?php echo e($user->email); ?></p>
                    <p><strong>Role:</strong>
                        <span class="badge px-3 py-2 rounded-pill text-white" style="background:
                            <?php echo e($user->role === 'admin' ? '#e63946' : ($user->role === 'teacher' ? '#ffb703' : '#219ebc')); ?>;
                        ">
                            <?php echo e(ucfirst($user->role)); ?>

                        </span>
                    </p>
                    <p><strong>Joined:</strong> <?php echo e($user->created_at->format('M d, Y')); ?></p>
                </div>
            </div>

            <!-- Courses Created -->
            <?php if($user->courses->count() > 0): ?>
            <div class="card border-0 shadow-lg mb-4">
                <div class="card-header text-white fw-bold" style="background:#2b2738;">
                    <i class="fas fa-book me-2"></i> Courses Created
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php $__currentLoopData = $user->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 mb-3">
                            <div class="card h-100 border-0 shadow-sm hover-shadow">
                                <div class="card-body">
                                    <h6 class="fw-bold text-dark">
                                        <i class="fas fa-graduation-cap text-primary me-1"></i> <?php echo e($course->name); ?>

                                    </h6>
                                    <p class="text-muted small"><?php echo e(Str::limit($course->description, 80)); ?></p>
                                    <span class="badge bg-success mb-2"><?php echo e($course->enrollments->count()); ?> students</span>
                                    <br>
                                    <a href="<?php echo e(route('courses.show', $course)); ?>" class="btn btn-sm text-white" style="background:#2b2738;">
                                        <i class="fas fa-eye me-1"></i> View
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Enrolled Courses -->
            <?php if($user->enrolledCourses->count() > 0): ?>
            <div class="card border-0 shadow-lg mb-4">
                <div class="card-header text-white fw-bold" style="background:#2b2738;">
                    <i class="fas fa-chalkboard-teacher me-2"></i> Enrolled Courses
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php $__currentLoopData = $user->enrolledCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 mb-3">
                            <div class="card h-100 border-0 shadow-sm hover-shadow">
                                <div class="card-body">
                                    <h6 class="fw-bold text-dark">
                                        <i class="fas fa-graduation-cap text-primary me-1"></i> <?php echo e($course->name); ?>

                                    </h6>
                                    <p class="text-muted small"><?php echo e(Str::limit($course->description, 80)); ?></p>
                                    <span class="badge bg-secondary mb-2">By <?php echo e($course->user->name); ?></span>
                                    <br>
                                    <a href="<?php echo e(route('courses.show', $course)); ?>" class="btn btn-sm text-white" style="background:#2b2738;">
                                        <i class="fas fa-eye me-1"></i> View
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Right Column -->
        <div class="col-lg-4">
            <div class="card border-0 shadow-lg">
                <div class="card-body text-center">
                    <div class="rounded-circle d-flex align-items-center justify-content-center mx-auto mb-3 shadow"
                        style="width:90px;height:90px;font-size:2rem;background:#2b2738;color:#fff;">
                        <?php echo e(strtoupper(substr($user->name, 0, 1))); ?>

                    </div>
                    <h5 class="fw-bold"><?php echo e($user->name); ?></h5>
                    <p class="text-muted"><?php echo e($user->email); ?></p>
                    <span class="badge text-white px-3 py-2" style="background:#2b2738;">
                        <?php echo e(ucfirst($user->role)); ?>

                    </span>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/creativy/lms.sekolahadvertiser.com/resources/views/users/profile.blade.php ENDPATH**/ ?>