<?php

namespace App\Http\Controllers;
use Laravel\Socialite\Facades\Socialite;


abstract class Controller
{
    //
}
